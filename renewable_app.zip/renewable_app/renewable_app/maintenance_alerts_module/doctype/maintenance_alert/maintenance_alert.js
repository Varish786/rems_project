// Copyright (c) 2024, varish and contributors
// For license information, please see license.txt

// frappe.ui.form.on("Maintenance Alert", {
// 	refresh(frm) {

// 	},
// });
