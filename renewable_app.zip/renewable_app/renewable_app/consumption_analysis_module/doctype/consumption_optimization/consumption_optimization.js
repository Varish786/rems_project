// Copyright (c) 2024, varish and contributors
// For license information, please see license.txt

// frappe.ui.form.on("Consumption Optimization", {
// 	refresh(frm) {

// 	},
// });
