frappe.ready(function() {

    function System_Monitor(response){
        let tableHTML = `<table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>Duration</th>
                <th>IP</th>
                <th>TimeStamp</th>
                <th>UUID</th>
            </tr>
        </thead>
        <tbody>`;

        response.forEach(user => {
        tableHTML += `
            <tr>
                <td>${user.duration}</td>
                <td>${user.request.ip}</td>
                <td>${user.timestamp}</td>
                <td>${user.uuid}</td>
            </tr>`;
    });

    tableHTML += `</tbody></table>`;

    // Insert the generated table into the users_table div
    document.querySelector(".system_status_table").innerHTML = tableHTML;
}
           
    

    frappe.call({
        method: "renewable_app.API.api.get_admin_dashboard",
        callback: function(response) {
            // ViewUsers(response.message.system_monitoring)
            System_Monitor(response.message.system_monitoring.data);
            
        },
        error: function(error) {
            console.error("Error fetching consumption report:", error);
            document.getElementsByClassName("system_status_table").innerText = "Failed to load data.";
        }
    });
});