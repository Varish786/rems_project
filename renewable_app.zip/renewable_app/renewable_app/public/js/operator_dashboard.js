frappe.ready(function () {

    function createTimelineChart(ctx, labels, maintenanceDates, maintenanceTypes, alertDates) {
        const data = {
            labels: labels,
            datasets: [
                {
                    label: 'Maintenance Date',
                    data: maintenanceDates,
                    backgroundColor: 'rgba(255, 99, 132, 0.2)',
                    borderColor: 'rgba(255, 99, 132, 1)',
                    borderWidth: 1,
                    barThickness: 10
                },
                {
                    label: 'Alert Date',
                    data: alertDates,
                    backgroundColor: 'rgba(54, 162, 235, 0.2)',
                    borderColor: 'rgba(54, 162, 235, 1)',
                    borderWidth: 1,
                    barThickness: 10
                }
            ]
        };

        new Chart(ctx, {
            type: 'bar',
            data: data,
            options: {
                indexAxis: 'y', // Horizontal bar chart
                scales: {
                    x: {
                        type: 'linear',
                        position: 'bottom',
                        title: {
                            display: true,
                            text: 'Date'
                        }
                    },
                    y: {
                        title: {
                            display: true,
                            text: 'Maintenance Type'
                        }
                    }
                },
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: function (context) {
                                const index = context.dataIndex;
                                return `${context.dataset.label}: ${context.raw} (${maintenanceTypes[index]})`;
                            }
                        }
                    }
                }
            }
        });
    }

    function createGroupedBarChart(ctx, labels, energyFlow, currentLevel, integrationEfficiency) {
        const groupedData = {
            labels: labels,
            datasets: [
                {
                    label: 'Energy Flow',
                    data: energyFlow,
                    backgroundColor: 'rgba(255, 99, 132, 0.2)',
                    borderColor: 'rgba(255, 99, 132, 1)',
                    borderWidth: 1
                },
                {
                    label: 'Current Level',
                    data: currentLevel,
                    backgroundColor: 'rgba(54, 162, 235, 0.2)',
                    borderColor: 'rgba(54, 162, 235, 1)',
                    borderWidth: 1
                },
                {
                    label: 'Integration Efficiency',
                    data: integrationEfficiency,
                    backgroundColor: 'rgba(75, 192, 192, 0.2)',
                    borderColor: 'rgba(75, 192, 192, 1)',
                    borderWidth: 1
                }
            ]
        };

        new Chart(ctx, {
            type: 'bar',
            data: groupedData,
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }


    function BarChart(ctx, type, labels, data, heading) {
        new Chart(ctx, {
            type: type,
            data: {
                labels: labels,
                datasets: [{
                    label: heading,
                    data: data,
                    backgroundColor: 'rgba(54, 162, 235, 0.2)',
                    borderColor: 'rgba(54, 162, 235, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }

    function createChart(section, type) {
        const container = document.getElementById("energy-production-table-container");
        const canvas = document.createElement("canvas");
        container.appendChild(canvas);
        const ctx = canvas.getContext('2d');
        let labels, data;

        if (section.heading === "Energy Production") {
            // Use "Energy Type" as labels and "Production Amount" as data for the Energy Production section
            labels = section.data.map(row => row["energy_type"]);
            data = section.data.map(row => row["production_amount"]);

            BarChart(ctx, 'bar', labels, data, "Energy Production");
        }
        if (section.heading === "Energy Consumption") {
            // Use "Location" as labels and "Consumption Amount" as data for the Energy Consumption section
            labels = section.data.map(row => row["location"]);
            data = section.data.map(row => row["consumption_amount"]);
       
            BarChart(ctx, 'bar', labels, data, "Energy Consumption");
        }


        if (section.heading === "Maintenance Alerts") {
            // Use "Maintenance Date", "Maintenance Type", and "Alert Date" for the Maintenance Alerts section
            labels = section.data.map(row => row["maintenance_date"]); // Use maintenance date as labels
            maintenanceDates = section.data.map(row => new Date(row["maintenance_date"]).getTime()); // Convert to timestamps
            alertDates = section.data.map(row => new Date(row["alert_date"]).getTime()); // Convert to timestamps
            maintenanceTypes = section.data.map(row => row["maintenance_type"]); // Use maintenance type for tooltips
            createTimelineChart(ctx, labels, maintenanceDates, maintenanceTypes, alertDates);
        }


        if (section.heading === "Grid Integration") {
            // Create grouped bar chart for "Grid Integration"
            const energyFlow = section.data.map(row => row["energy_flow"]);
            const currentLevel = section.data.map(row => row["current_level"]);
            const integrationEfficiency = section.data.map(row => row["integration_efficiency"]);
            labels = section.data.map(row => row["timestamp"]); // Use timestamp or another suitable field for labels
            createGroupedBarChart(ctx, labels, energyFlow, currentLevel, integrationEfficiency);

        }

    }

    function createTable(section) {

        const container = document.getElementById("energy-production-table-container");

        const table = document.createElement("table");
        table.classList.add("table", "table-bordered", "border-dark");

        // Create table header
        const thead = document.createElement("thead");
        thead.classList.add("table_heading", "table-dark");
        const headerRow = document.createElement("tr");
        // headerRow.classList.add("table_row");

        section.columns.forEach(column => {
            const th = document.createElement("th");
            th.textContent = column.label;
            table.classList.add("heading");
            headerRow.appendChild(th);
        });

        thead.appendChild(headerRow);
        table.appendChild(thead);

        // Create table body
        const tbody = document.createElement("tbody");
        tbody.classList.add("table_tbody");
        section.data.forEach(row => {
            const tr = document.createElement("tr");

            section.columns.forEach(column => {
                const td = document.createElement("td");
                td.textContent = row[column.fieldname] !== undefined ? row[column.fieldname] : "N/A";  // Display "N/A" if field is missing
                tr.appendChild(td);
            });

            tbody.appendChild(tr);
        });
        const heading = document.createElement("h4")
        heading.textContent = section.heading

        container.appendChild(heading);
        table.appendChild(tbody);
        container.appendChild(table);
    }


    function handleApiResponse(data) {

        // Clear the container before appending new content
        const container = document.getElementById("energy-production-table-container");
        container.innerHTML = "";

        if (data.energy_consumption) {
            createTable(data.energy_consumption);
            createChart(data.energy_consumption, 'bar');  // Bar chart for Energy Consumption
        }

        if(data.energy_production){
            createTable(data.energy_production)
            createChart(data.energy_production, 'bar');  // Bar chart for Energy Consumption
        }

        if (data.maintenance_alerts) {
            createTable(data.maintenance_alerts)
            createChart(data.maintenance_alerts, 'bar');  // Bar chart for Energy Consumption
        }
        if (data.grid_integration) {
            createTable(data.grid_integration)
            createChart(data.grid_integration, 'bar');  // Bar chart for Energy Consumption
        }

    }
    

 
    // Call API and process the response
    frappe.call({
        method: "renewable_app.API.api.get_operator_dashboard",
        args: {
            from_date: "2024-08-01",
            to_date: "2024-08-31"
        },
        callback: function (response) {
            if (response.message) {
                handleApiResponse(response.message);
            } else {
                console.error("No data received from API");
                document.getElementById("energy-production-table-container").innerText = "No data available.";
            }
        },
        error: function (error) {
            console.error("Error fetching operator dashboard data:", error);
            document.getElementById("energy-production-table-container").innerText = "Failed to load data.";
        }
    });
});








// document.addEventListener('DOMContentLoaded', function () {
//     const form = document.getElementById('date-range-form');

//     form.addEventListener('submit', function (event) {
//         event.preventDefault(); // Prevent form from submitting normally

//         // Get the selected dates
//         const fromDate = document.getElementById('from_date').value;
//         const toDate = document.getElementById('to_date').value;

//         // Validate the date range
//         if (new Date(fromDate) > new Date(toDate)) {
//             alert('From Date cannot be later than To Date');
//             return;
//         }
//         GetDate(fromDate,toDate)
   
        
//         // Make the API call with the selected dates
//         // frappe.call({
//         //     method: "renewable_app.API.api.get_operator_dashboard",
//         //     args: {
//         //         from_date: fromDate,
//         //         to_date: toDate
//         //     },
//         //     callback: function (response) {
//         //         if (response.message) {
//         //             handleApiResponse(response.message);
//         //         } else {
//         //             console.error("No data received from API");
//         //             document.getElementById("energy-production-table-container").innerText = "No data available.";
//         //         }
//         //     },
//         //     error: function (error) {
//         //         console.error("Error fetching operator dashboard data:", error);
//         //         document.getElementById("energy-production-table-container").innerText = "Failed to load data.";
//         //     }
//         // });
//     });
// });
