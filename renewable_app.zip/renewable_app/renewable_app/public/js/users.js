frappe.ready(function() {

    function ViewUsers(response){
        let tableHTML = `<table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>User ID</th>
                <th>Name</th>
                <th>Role</th>
                <th>Contact Information</th>
            </tr>
        </thead>
        <tbody>`;

        response.forEach(user => {
        tableHTML += `
            <tr>
                <td>${user.user_id}</td>
                <td>${user.name1}</td>
                <td>${user.role}</td>
                <td>${user.contact_information}</td>
            </tr>`;
    });

    tableHTML += `</tbody></table>`;

    // Insert the generated table into the users_table div
    document.querySelector(".users_table").innerHTML = tableHTML;
}
           
    

    frappe.call({
        method: "renewable_app.API.api.get_admin_dashboard",
        callback: function(response) {
            ViewUsers(response.message.user_management)
        },
        error: function(error) {
            console.error("Error fetching consumption report:", error);
            document.getElementsByClassName("users_table").innerText = "Failed to load data.";
        }
    });
});






// frappe.ready(function() {
//     function ViewUsers(response) {
        
      
//     }

//     // Attach click event listener to the "View Users" button
//     document.getElementById("view-users-btn").addEventListener("click", function() {
//         frappe.call({
//             method: "renewable_app.API.api.get_admin_dashboard",
//             callback: function(response) {
//                 ViewUsers(response.message.user_management); 
//             },
//             error: function(error) {
//                 console.error("Error fetching data:", error);
//                 document.getElementById("consumption-report").innerText = "Failed to load data.";
//             }
//         });
//     });



// });
