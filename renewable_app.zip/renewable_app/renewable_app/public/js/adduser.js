frappe.ready(function() {
    document.getElementById("userForm").addEventListener("submit", function(event) {
        event.preventDefault(); 

        const userData = {
            user_id: document.getElementById("user_id").value,
            name1: document.getElementById("name1").value,
            role: document.getElementById("role").value,
            contact_information: document.getElementById("contact_information").value
        };

        frappe.call({
            method: "renewable_app.API.api.create_user",
            args: userData, // Pass data as separate arguments
            callback: function(response) {
                if (response.message.status === "success") {
                    // Show success message
                    document.getElementById("successMessage").style.display = "block";
                    
                    // Hide the success message after 3 seconds
                    setTimeout(function() {
                        document.getElementById("successMessage").style.display = "none";
                    }, 3000);

                    // Optional: Clear the form after submission
                    document.getElementById("userForm").reset();
                } else {
                    // Handle error case
                    console.error("Error:", response.message.message);
                }
            },
            error: function(error) {
                console.error("Error:", error);
            }
        });
    });
});
