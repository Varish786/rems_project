frappe.ready(function() {

    function Reports_status(response) {
        console.log("response", response);
        
        let tableHTML = `<table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>Report Name</th>
                <th>Last Modified</th>
                <th>Module</th>
                <th>Doctype</th>
            </tr>
        </thead>
        <tbody>`;
    
        // Iterate over the keys in the response object
        for (const report in response) {
            if (response.hasOwnProperty(report)) {
                const reportData = response[report];
                tableHTML += `
                <tr>
                    <td>${reportData.name}</td>
                    <td>${reportData.modified}</td>
                    <td>${reportData.module}</td>
                    <td>${reportData.doctype}</td>
                </tr>`;
            }
        }
    
        tableHTML += `</tbody></table>`;
    
        // Insert the generated table into the report_status_table div
        document.querySelector(".report_status_table").innerHTML = tableHTML;
    }
    
           
    

    frappe.call({
        method: "renewable_app.API.api.get_admin_dashboard",
        callback: function(response) {
            Reports_status(response.message.reports.reports)
        },
        error: function(error) {
            console.error("Error fetching consumption report:", error);
            document.getElementsByClassName("report_status_table").innerText = "Failed to load data.";
        }
    });
});