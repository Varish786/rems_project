// Copyright (c) 2024, varish and contributors
// For license information, please see license.txt

frappe.query_reports["Grid Integration Report"] = {
	"filters": [

	]
};
