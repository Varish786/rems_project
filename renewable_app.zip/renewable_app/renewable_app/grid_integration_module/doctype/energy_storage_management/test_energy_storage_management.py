# Copyright (c) 2024, varish and Contributors
# See license.txt

# import frappe
from frappe.tests.utils import FrappeTestCase


class TestEnergyStorageManagement(FrappeTestCase):
	pass
